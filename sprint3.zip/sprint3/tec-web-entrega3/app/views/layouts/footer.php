<div>
    <br>
    <br>
    <br>
    <br>
</div>
<footer class="fixed-bottom" >
    <div class="row" style="height: 40px;">
        <div class="col-sm-2" style="background-color: #395143;">
            &emsp;
        </div>
        <div class="col-sm-10" style="background-color: #B6D422; text-align: center; padding: 10px;">
            &copy; Todos os direitos reservados
        </div>
    </div>
</footer>